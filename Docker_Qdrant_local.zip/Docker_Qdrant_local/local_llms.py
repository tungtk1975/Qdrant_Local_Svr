import requests, json
from qdrant_client.http import models
from qdrant_client import QdrantClient
from llama_index.schema import TextNode
from llama_index import  SimpleDirectoryReader
from llama_index.node_parser import SimpleNodeParser
vocab_bpe_path = '/core/vocab.bpe'
# Create an instance of SimpleNodeParser using the specified path
node_parser = SimpleNodeParser(vocab_bpe_path)


from llama_index.node_parser.text.sentence import SentenceSplitter
from sentence_transformers import SentenceTransformer

def llm_request(prompt, url:str='http://203.113.132.109:11434/api/generate', model:str='mistral'):

    # Gửi yêu cầu POST đến API
    response = requests.post(url, json={"model": model, "prompt": prompt})

    # Chuyển đổi byte thành list của dictionaries
    sub_responses = [json.loads(res) for res in response.text.strip().split('\n')]

    # Lặp qua tất cả các phản hồi và nối các phần "response" (nếu có)
    text_response = "".join(item["response"] for item in sub_responses if "response" in item)
    
    return text_response


def embedding(text):
    return SentenceTransformer('paraphrase-MiniLM-L6-v2').encode(text)

def data_processing(localfolder):
    loaded_docs = SimpleDirectoryReader(input_dir=localfolder).load_data()
    text_parser = SentenceSplitter(
        chunk_size=512,
        chunk_overlap=128,
        separator=" ",
    )
    nodes = []
    text_chunks = []
    doc_idxs = []
    # maintain relationship with source doc index, to help inject doc metadata in (3)
    for doc_idx, doc in enumerate(loaded_docs):
        cur_text_chunks = text_parser.split_text(doc.text)
        text_chunks.extend(cur_text_chunks)
        doc_idxs.extend([doc_idx] * len(cur_text_chunks))
        
    for idx, text_chunk in enumerate(text_chunks):
        node = TextNode(
            text=text_chunk,
        )
        src_doc = loaded_docs[doc_idxs[idx]]
        node.metadata = src_doc.metadata
        nodes.append(node)
    for node in nodes:
        node.text = " ".join(node.text.split('\n'))
        node.text = " ".join(node.text.split('\t'))
        node.text = " ".join(node.text.split(" "))
        node.embedding = embedding(node.text)
        print(f"Processed node: {node.id_}\n")

    return nodes

def qdrant_collection_def(qdrant_collection:str='PVNDB', embedding_dim:str=384):
    client = QdrantClient("203.113.132.109:6333")
    try:
        client.create_collection(
            collection_name=qdrant_collection,
            vectors_config=models.VectorParams(size=embedding_dim, distance=models.Distance.COSINE),
        )
    except:
        pass
    return client

def qdrant_uploader(client, qdrant_collection, nodes):
    points=[]
    for node in nodes:
        point = models.PointStruct(
                id=node.id_,
                vector=node.embedding,
                payload={
                    "page_content": node.get_content(),
                    "file_name": node.metadata['file_name'],
                    "file_path": node.metadata['file_path'],
                    "file_type": node.metadata['file_type'],
                },
            )
        points.append(point)
        print(f"Processing Document ID: {node.id_}, File Name: {node.metadata['file_name']}")
    client.upsert(collection_name=qdrant_collection, points=points)
    print("Qdrant Upserting Finished!")

def prompt_generator(hints, user_query):
    _hints = ""
    for i in range(len(hints)):
        _hints += hints[i].payload['page_content'] + "\n\n"
    prompt = f"""
    You are an AI assistant designed by Vietnam Petroleum Institute. Answer the given question based on the context below. If the context does not have enough information, please answer "I don't have enough information"
    Context:
    {_hints}
    Question:
    {user_query}
    Assistant:
    """
    return prompt

def print_out_ans(user_query, final_ans, hints):
    refer = ""
    for i in range(len(hints)):
        refer += f"Reference {i+1}. Score: {round(hints[0].score, 3)}, File name: {hints[0].payload['file_name']}\n"
    _print_out = f"""
    Question: {user_query}
    Answer: {final_ans}
    References:
        {refer}
    """
    return _print_out
